package application.processor.input;

public class RandomData {
    static public final String[] maleNamesArray = {"Ivan", "Artem", "Aleksander", "Silvester",  "Artur", "Maxim", "Grigoriy", "Efim", "John", "Alexey",
            "Dominic", "Vasiliy", "Oleg", "Akakiy", "Sergey", "Nikolya", "Tihon", "Ilya", "Ildar", "Svyatoslav",
            "Elisey", "Anatoliy", "Ibragym", "Takumi", "Charlie", "Shaman", "Kesha", "Konstantin", "Evgeniy", "Ravshan", "Vladimir"};
    static public final String[] womenNamesArray = {"Olga", "Alina", "Svetlana", "Anastasia", "Anjelika", "Eva", "Madonna", "Viktoria", "Elena", "Natalya",
            "Afdotya", "Vasilisa", "Alena", "Angelina", "Alla", "Oksana", "Leti", "Nazuki", "Karina", "Yana",
            "Milena", "Valeriya", "Irina", "Darya", "Anna", "Polina", "Ekaterina", "Alisa", "Maria", "Galina", "Monika", "Aleksandra"};
    static public final String[] maleLastNamesArray = {"Ivanov", "Kolesnikov", "Stalone", "Swarcneger", "Kochetkov", "Shumilov", "Serov", "Fujivara", "Toretto", "Polezhaikin",
            "Ahmedov", "Abubakirov", "Kvasov", "Korzhukov", "Negreev", "Zolo", "Pushkin", "Tatarkin", "Kramarchuk", "Tramp",
            "Belozerov", "Bataikin", "Tihonov", "Danilec", "Rahmatulin", "Baturin", "Domrachev", "Suharev", "Grinkin", "Soloviev", "Mazurov"};
    static public final String[] womenLastNamesArray = {"Ivanova", "Kolesnikova", "Stalone", "Swarcneger", "Kochetkova", "Shumilova", "Serova", "Fujivara", "Toretto", "Polezhaikina",
            "Ahmedova", "Abubakirova", "Kvasova", "Korzhukova", "Negreeva", "Zolo", "Pushkina", "Tatarkina", "Kramarchuk", "Tramp",
            "Belozerova", "Bataikina", "Tihonova", "Danilec", "Rahmatulina", "Baturina", "Domracheva", "Suhareva", "Grinkina", "Solovieva", "Mazurov"};
}
