package test.test_processor;

import application.entity.Person;
import application.processor.Processor;

public class ProcessorTest{
    public static void main(String[] args) {
        Processor<Person> processor;
    }
}
